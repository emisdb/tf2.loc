<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1 style="font-size: 48px;">Welcome to <a href="https://notes.thecodeholic.com">notes.thecodeholic.com</a></h1>

        <p class="lead">The is the API domain.
          <br>Click the
          <a href="https://notes.thecodeholic.com">following link</a> if you want to see demo.
        </p>
    </div>
</div>
