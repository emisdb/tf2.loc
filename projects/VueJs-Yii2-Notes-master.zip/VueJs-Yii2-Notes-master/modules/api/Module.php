<?php
/**
 * User: TheCodeholic
 * Date: 3/7/2020
 * Time: 9:17 AM
 */

namespace app\modules\api;


/**
 * Class Module
 *
 * @author Zura Sekhniashvili <zurasekhniashvili@gmail.com>
 * @package app\modules\api
 */
class Module extends \yii\base\Module
{

}
