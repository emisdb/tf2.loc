<?php
/**
 * User: TheCodeholic
 * Date: 3/7/2020
 * Time: 9:36 AM
 */

namespace app\modules\api\resources;


use app\models\Note;

/**
 * Class NoteResource
 *
 * @author Zura Sekhniashvili <zurasekhniashvili@gmail.com>
 * @package app\modules\api\resources
 */
class NoteResource extends Note
{

}
